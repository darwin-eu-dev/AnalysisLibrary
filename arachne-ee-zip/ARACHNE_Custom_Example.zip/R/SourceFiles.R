getThisPackageName <- function() {return("GenerateSurvival")}
getPathToCsv <- function() {return("inst/settings/")}
pathToCsv <- function() {return(here::here("inst/settings/CohortsToCreate.csv"))}


