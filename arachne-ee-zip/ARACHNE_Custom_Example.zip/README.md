# Custom R package example

The package could be used as inspiration and base project for you analysis.
